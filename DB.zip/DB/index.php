<?php
require_once('views/layout/header.php');
require_once('controllers/Services.php');
?>
<div style="background-color: #60ee9f; background-image: url('images/XXL.jpeg');background-size: cover;background-repeat: no-repeat;height: 300px">
        <div class="buttones">
            <a class="knopka" href="/views/auth/auth.php">Авторизация</a>
        </div>
        <div class="logo">
            <a href="/index.php"><img src="images/pngwing.com.png" alt="images/pngwing.com.png" width="60"></a>
        </div>
            <div style="padding-left: 100px;">
                <a class="knopka" href="news.php">Новости</a>
            </div>
    </div>
<?php
if (isset($_GET['message'])) {
    echo $_GET['message'];
}
?>
    <div class="container mx-auto">
        <div style="display: grid; grid-template-columns: repeat(3,1fr)">
            <?php
            $user = new Services();
            $data = $user->getData();
            foreach ($data as $key => $row) {
                ?>
    <div>
    <figure class="snip1336">
        <figcaption>
            <h4><?php echo $row['service']; ?><span>"Печка, утюг и другие"</span></h4>
            <p>Сроки:<?php echo $row['deadlines']; ?> </p>
            <p>Стоимость:<?php echo $row['price']; ?> </p>
        </figcaption>
    </figure>
</div>
<?php } ?>