<?php
require ('layout/header.php');
require ('../controllers/Services.php');
?>
<div>
    <a class="knopka" href="users/index.php">В меню</a>
</div>
    <div class=" container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
        <a class="knopka" href="users/create_services.php">Добавить услугу</a>
        <a class="knopka" href="users/update_service.php">Изменить услугу</a>
        <a class="knopka" href="users/delete_service.php">Удалить услугу</a>
    </div>
    <title>Технический отдел по ремонту техники</title>
    <div class="container mx-auto">
        <table class="table table-hover table-info">
            <thead>
            <tr>
                <th> </th>
                <th>Название</th>
                <th>Сроки</th>
                <th>Стоимость</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db= new Services();
            $data = $db->getData();
            foreach ($data as $key=>$row){
                ?>
                <tr>
                    <td><?php echo ++$key;?></td>
                    <td><?php echo $row['service'];?></td>
                    <td><?php echo $row['deadlines'];?></td>
                    <td><?php echo $row['price'];?></td>
                </tr>
            <?php }?>
            </tbody>
        </table>
    </div>
