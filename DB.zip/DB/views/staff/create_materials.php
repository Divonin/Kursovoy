<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Materials.php');
?>
<div>
    <a class="knopka" href="../auth/menu.php">В меню</a>
</div>
<label class="labelor">Телефон: 88005553535</label>
<style>
    .labelor{
        color: #000000;
        background-color: #e6dbb9;
        padding: .5em 1.5em;
    }
</style>
<div class="container mt-5">
    <form action="../../middleware/staff/createMaterials.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3 class="labelor">Создание</h3>
        <div class="col-3">
            <label for="name">Название</label>
            <input id="name" name="name" type="text" class="form-control" placeholder="Введите название" required>
        </div>
        <div class="col-3">
            <label for="price">Стоимость</label>
            <input id="price" name="price" type="text" class="form-control" placeholder="Введите стоимость" required>
        </div>
        <div class="col-3">
            <label for="count">Кол-во</label>
            <input id="count" name="count" type="text" class="form-control" placeholder="Кол-во" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Добавить</button>
        </div>
    </form>
</div>
