<?php
require ('../layout/header.php');
require ('../../controllers/Equipment.php');
?>
<div>
    <a class="knopka" href="../auth/menu.php">В меню</a>
</div>
    <style>
        a.knopka {
            color: #fff; /* цвет текста */
            text-decoration: none; /* убирать подчёркивание у ссылок */
            background: rgb(59, 177, 173); /* фон кнопки */
            padding: .3em .8em; /* отступ от текста */
        }
        a.knopka:hover { background: rgb(97, 252, 245); } /* при наведении курсора мышки */
        a.knopka:active { background: rgb(175, 225, 224); } /* при нажатии */
    </style>
    <div class="container d-flex justify-content-between align-items-center p-2 mb-2">
        <div>
            <a class="knopka" href="equipment_create.php">Добавить оборудование</a>
            <a class="knopka" href="equipment_update.php">Изменить оборудование</a>
        </div>
    </div>
    <title>Технический отдел по ремонту техники</title>
    <div class="container mx-auto">
        <table class="table table-hover table-dark">
            <thead>
            <tr>
                <th> </th>
                <th>Название</th>
                <th>Предназначение</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db= new Equipment();
            $data = $db->Getdata();
            foreach ($data as $key=>$row){
                ?>
                <tr>
                    <td><?php echo ++$key;?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['affiliation'];?></td>
                </tr>
            <?php }?>
            </tbody>
        </table>
    </div>
