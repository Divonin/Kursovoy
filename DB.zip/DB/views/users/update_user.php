<?php
require_once ('../layout/header.php');
require_once ('menu2.php');
require_once ('../../controllers/User.php');
$db=new User();
?>
    <table class="table table-hover table-info">
        <thead>
        <tr>
            <th>id</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Пароль</th>
            <th>Статус</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php
        $data = $db->getU();
        foreach ($data as $key => $row) {
            ?>
            <tr>
                <form class="mx-2" action="../../middleware/updateU.php" method="post">
                    <td>
                        <?php echo ++$key; ?>
                        <input id="id_users" name="id_users" type="text" value="<?php echo $row["id_users"]; ?>" class="form-control" hidden
                               required>
                    </td>
                    <td><?php echo $row["last_name"]; ?></td>
                    <td><?php echo $row["name"]; ?></td>
                    <td><?php echo $row["father_name"]; ?></td>
                    <td>
                        <input id="password" name="password" type="text" value="<?php echo $row["password"]; ?>"
                               class="form-control" required>
                    </td>
                    <td><?php echo $row["role"]; ?></td>
                    <td>
                        <button type="submit" class="btn btn-primary">Изменить</button>
                    </td>
                </form>
            </tr>
        <?php } ?>
        </tbody>
    </table>