<?php
require('../../controllers/Materials.php');
$db = new Materials();
$name = $_POST['name'];
$price = $_POST['price'];
$count = $_POST['count'];
$response = $db->createMaterials(json_encode([
    'name'=>$name,
    'price'=>$price,
    'count'=>$count,
]));

header('Location: ../../views/staff/materials.php?message='.json_decode($response)->message);
