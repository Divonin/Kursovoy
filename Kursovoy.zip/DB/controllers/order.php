<?php
require ('db.php');
class order extends DB
{
    public function get(){
        return $this->DBAll('SELECT * from orders');
    }
    public function deleteOrder($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from orders where id='.$req->id,
            'Заказ отменён');
    }

    public function createOrder($request){
        $req = json_decode($request);
        $name = $req->name;
        $price = $req->price;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO orders (name, price) values ('{$name}','{$price}')");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateOrder($request){
        $req = json_decode($request);
        $id = $req->id;
        $name = $req->name;
        $price = $req->price;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE orders SET name='{$name}',price='{$price}' WHERE id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}