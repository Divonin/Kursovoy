<?php

require ('db.php');

class Materials extends DB
{
    public function GetData(){
        return $this->DBAll('SELECT * from materials');
    }
}