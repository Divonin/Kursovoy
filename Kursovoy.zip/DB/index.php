<?php
require_once('views/layout/header.php');
require_once('controllers/Services.php');
?>
<label class="labelor">Телефон: 88005553535</label>
<style>
    .labelor{
    color: #000000;
        padding: .5em 1.5em;
    }
</style>
<style>
a.knopka {
color: #fff; /* цвет текста */
text-decoration: none; /* убирать подчёркивание у ссылок */
background: rgb(59, 177, 173); /* фон кнопки */
padding: .3em .8em; /* отступ от текста */
}
a.knopka:hover { background: rgb(97, 252, 245); } /* при наведении курсора мышки */
a.knopka:active { background: rgb(175, 225, 224); } /* при нажатии */
</style>
<div>
    <a class="accordion-button" href="/index.php">Главная страница</a>
</div>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/public/css/bootstrap.min.css">
    <title>Технический отдел по ремонту техники</title>
</head>
<body>
<?php
if(isset($_GET['message'])){
    echo $_GET['message'];
}
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div>
        <a class="knopka" href="/views/auth/auth.php">Авторизация</a>
    </div>
    <div>
        <a class="knopka" href="/views/auth/registration.php">Регистрация</a>
    </div>
</div>
<title>Технический отдел по ремонту техники</title>
<div class="container mx-auto">
    <table class="table table-hover table-dark">
        <thead>
        <tr>
            <th> </th>
            <th>Название</th>
            <th>Сроки</th>
            <th>Стоимость</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $db= new Services();
        $data = $db->getData();
        foreach ($data as $key=>$row){
            ?>
            <tr>
                <td><?php echo ++$key;?></td>
                <td><?php echo $row['service'];?></td>
                <td><?php echo $row['deadlines'];?></td>
                <td><?php echo $row['price'];?></td>
            </tr>
        <?php }?>
        </tbody>
    </table>
</div>
