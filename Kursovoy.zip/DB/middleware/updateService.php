<?php
require_once('../controllers/Services.php');
$db = new Services();
$id = $_POST['id'];
$service = $_POST['service'];
$deadlines = $_POST['deadlines'];
$price = $_POST['price'];

$res = $db->updateService(json_encode([
    'id'=>$id,
    'service'=>$service,
    'deadlines'=>$deadlines,
    'price'=>$price,
]));

header('Location: ../index2.php?message='.json_decode($res)->message);
