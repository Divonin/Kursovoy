<?php
require_once('../../controllers/Orders.php');
$db = new Orders();
$id = $_POST['id'];
$start = $_POST['start'];
$end = $_POST['end'];
$name = $_POST['name'];
$price = $_POST['price'];

$res = $db->updateOrders(json_encode([
    'id'=>$id,
    'start'=>$start,
    'end'=>$end,
    'name'=>$name,
    'price'=>$price,
]));

header('Location: ../../views/auth/menu.php?message='.json_decode($res)->message);
