<?php
require_once('../../controllers/order.php');
$db = new order();
$name = $_POST['name'];
$price = $_POST['price'];

$response = $db->createOrder(json_encode([
    'name'=>$name,
    'price'=>$price,
]));

header('Location: ../../views/auth/index.php?message='.json_decode($response)->message);
