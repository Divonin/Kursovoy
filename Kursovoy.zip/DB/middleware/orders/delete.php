<?php
require_once ('../../controllers/order.php');
$db = new order();
$id = $_POST['id'];

$res = $db->deleteOrder(json_encode([
    'id'=>$id
]));

header('Location: ../../views/auth/index.php?message='. json_decode($res)->message);