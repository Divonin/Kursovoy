<?php
require_once('../../controllers/order.php');
$db = new order();
$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];

$res = $db->updateOrder(json_encode([
    'id'=>$id,
    'name'=>$name,
    'price'=>$price,
]));

header('Location: ../../views/auth/index.php?message='.json_decode($res)->message);