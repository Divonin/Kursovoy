<script src="../../public/js/bootstrap.bundle.min.js"></script>
</body>
</html>
