<?php
require ('../layout/header.php');
require ('menu.php');
require ('../../controllers/User.php');
?>
    <title>Технический отдел по ремонту техники</title>
<div class="container mx-auto">
    <table class="table">
        <tr>
            <th>id</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Специализация</th>
            <th>Опыт работы</th>
        </tr>
        <?php
        $user = new User();
        $data = $user->get();
        foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo $row ['id']?></td>
            <td><?php echo $row ['last_name']?></td>
            <td><?php echo $row ['name']?></td>
            <td><?php echo $row ['father_name']?></td>
            <td><?php echo $row ['Specialization']?></td>
            <td><?php echo $row ['Experience']?></td>
        </tr>
            <?php }?>
    </table>
</div>
<?php
require ('../layout/footer.php');
?>