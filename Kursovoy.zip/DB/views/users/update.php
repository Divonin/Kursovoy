<?php
require_once('../layout/header.php');
require_once('../../controllers/User.php');
$db = new User();
?>
    <table class="table table-hover table-dark">
        <thead>
        <tr>
            //*<th>id</th>*//
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Специализация</th>
            <th>Опыт работы</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $data = $db->get();
        foreach ($data as $key => $row) {
            ?>
            <tr>
                <form class="mx-2" action="../../middleware/update.php" method="post">
                    <td>
                        <?php echo ++$key; ?>
                        <input id="id" name="id" type="text" value="<?php echo $row["id"]; ?>" class="form-control" hidden
                               required>
                    </td>
                    <td>
                        <input id="FIO" name="FIO" type="text" value="<?php echo $row["last_name"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="FIO" name="FIO" type="text" value="<?php echo $row["name"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="FIO" name="FIO" type="text" value="<?php echo $row["father_name"]; ?>" class="form-control"
                               required>
                    </td>
                    <td>
                        <input id="Specialization" name="Specialization" type="text"
                               value="<?php echo $row["Specialization"]; ?>" class="form-control" required>
                    </td>
                    <td>
                        <input id="Experience" name="Experience" type="text" value="<?php echo $row["Experience"]; ?>"
                               class="form-control" required>
                    </td>
                    <td>
                        <button type="submit" class="btn btn-primary">Изменить</button>
                    </td>
                </form>
            </tr>
        <?php } ?>
        </tbody>
    </table>
<?php
require_once('../layout/footer.php');
?>