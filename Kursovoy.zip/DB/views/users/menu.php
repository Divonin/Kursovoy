<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <style>
        a.knopka {
            color: #fff; /* цвет текста */
            text-decoration: none; /* убирать подчёркивание у ссылок */
            background: rgb(59, 177, 173); /* фон кнопки */
            padding: .1em .7em; /* отступ от текста */
        }
        a.knopka:hover { background: rgb(97, 252, 245); } /* при наведении курсора мышки */
        a.knopka:active { background: rgb(175, 225, 224); } /* при нажатии */
    </style>
    <div>Сотрудники</div>
    <div>
        <a class="knopka" href="create.php">Добавить сотрудника</a>
        <a class="knopka" href="update.php">Изменить данные сотрудника</a>
        <a class="knopka" href="delete.php">Удалить сотрудника</a>
        <a class="knopka" href="create_services.php">Добавить услугу</a>
        <a class="knopka" href="update_service.php">Изменить услугу</a>
        <a class="knopka" href="delete_service.php">Удалить услугу</a>
    </div>
</div>