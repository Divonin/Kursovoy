<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
$db = new Orders();
?>
    <!doctype html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="/public/css/bootstrap.min.css">
        <title>Технический отдел по ремонту техники</title>
    </head>
<body>
<style>
    a.knopka {
        color: #fff; /* цвет текста */
        text-decoration: none; /* убирать подчёркивание у ссылок */
        background: rgb(59, 177, 173); /* фон кнопки */
        padding: .3em .8em; /* отступ от текста */
    }
    a.knopka:hover { background: rgb(97, 252, 245); } /* при наведении курсора мышки */
    a.knopka:active { background: rgb(175, 225, 224); } /* при нажатии */
</style>
<?php
if(isset($_GET['message'])){
    echo $_GET['message'];
}
?>
    <div>
        <a class="knopka" href="menu.php">Действия с заказами</a>
    </div>
    <table class="table table-hover table-dark">
        <thead>
        <tr>
            <th> </th>
            <th>Начало</th>
            <th>Окончание</th>
            <th>Название услуги</th>
            <th>Стоимость</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $data = $db->get();
        foreach ($data as $key=>$row){
            ?>
            <tr>
                <td><?php echo ++$key;?></td>
                <td><?php echo $row['start'];?></td>
                <td><?php echo $row['end'];?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['price'];?></td>
            </tr>
        <?php }?>
        </tbody>
    </table>
<?php
require ('../../views/layout/footer.php');
?>