<div>
    <a class="accordion-button" href="../auth/index2.php">Главная страница</a>
</div>
<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
?>
<style>
    a.knopka {
        color: #fff; /* цвет текста */
        text-decoration: none; /* убирать подчёркивание у ссылок */
        background: rgb(59, 177, 173); /* фон кнопки */
        padding: .3em .8em; /* отступ от текста */
    }
    a.knopka:hover { background: rgb(97, 252, 245); } /* при наведении курсора мышки */
    a.knopka:active { background: rgb(175, 225, 224); } /* при нажатии */
</style>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div>Заказы</div>
    <div>
        <a class="knopka" href="../staff/create.php">Добавить заказ</a>
        <a class="knopka" href="../staff/update.php">Изменить данные заказа</a>
        <a class="knopka" href="../staff/delete.php">Удалить заказ</a>
        <a class="knopka" href="../staff/equipment.php">Оборудование</a>
        <a class="knopka" href="../staff/materials.php">Материалы</a>
    </div>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>Начало</th>
        <th>Окончание</th>
        <th>Название услуги</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $db= new Orders();
    $data = $db->get();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['start'];?></td>
            <td><?php echo $row['end'];?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['price'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>
<?php
require ('../layout/footer.php');
?>