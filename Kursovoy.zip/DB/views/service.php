<?php
require ('layout/header.php');
require ('../controllers/Services.php');
?>
    <title>Технический отдел по ремонту техники</title>
    <div class="container mx-auto">
        <table class="table table-hover table-dark">
            <thead>
            <tr>
                <th> </th>
                <th>Название</th>
                <th>Сроки</th>
                <th>Стоимость</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db= new Services();
            $data = $db->getData();
            foreach ($data as $key=>$row){
                ?>
                <tr>
                    <td><?php echo ++$key;?></td>
                    <td><?php echo $row['service'];?></td>
                    <td><?php echo $row['deadlines'];?></td>
                    <td><?php echo $row['price'];?></td>
                </tr>
            <?php }?>
            </tbody>
        </table>
    </div>
<?php
require ('layout/footer.php');
?>