<div>
    <a class="accordion-button" href="../auth/index.php">Главная страница</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/Orders.php');
?>
    <div class="container mt-5">
        <form action="../../middleware/orders/createOrders.php"
              method="post"
              class="d-flex flex-column justify-content-center align-items-center">
            <h3>Создание</h3>
            <div class="col-8">
                <label for="name">Название услуги</label>
                <input id="name" name="name" type="text" class="form-control" placeholder="Введите название услуги" required>
            </div>
            <div class="col-">
                <label for="price">Стоимость</label>
                <input id="price" name="price" type="text" class="form-control" placeholder="Стоимость" required>
            </div>
            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Отправить</button>
            </div>
        </form>
    </div>
<?php
require ('../layout/footer.php');
?>