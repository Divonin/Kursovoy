<div>
    <a class="accordion-button" href="../auth/index2.php">Главная страница</a>
</div>
<?php
require_once('../layout/header.php');
require_once('../../controllers/Orders.php');
$db = new Orders();
?>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th>id</th>
        <th>Начало</th>
        <th>Конец</th>
        <th>Название услуги</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->get();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/orders/update.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row["id"]; ?>" class="form-control" hidden
                           required>
                </td>
                <td>
                    <input id="start" name="start" type="text" value="<?php echo $row["start"]; ?>" class="form-control"
                           required>
                </td>

                <td>
                    <input id="end" name="end" type="text" value="<?php echo $row["end"]; ?>" class="form-control"
                           required>
                </td>
                <td>
                    <input id="name" name="name" type="text"
                           value="<?php echo $row["name"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="price" name="price" type="text" value="<?php echo $row["price"]; ?>"
                           class="form-control" required>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>
<?php
require_once('../layout/footer.php');
?>