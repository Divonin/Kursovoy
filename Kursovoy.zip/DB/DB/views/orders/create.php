<div>
    <a class="knopka" href="../auth/menu2.php">В меню</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/order.php');
?>
<head>
    <script lang="javascript" type="text/javascript"></script>
</head>
<script>
    window.onload = function () {
        var url = document.location.href,
            params = url.split('?')[1].split('&'),
            data = {}, tmp;
        for (var i = 0, l = params.length; i < l; i++) {
            tmp = params[i].split('=');
            data[tmp[0]] = tmp[1];
        }
        document.getElementById('here').innerHTML = data.service;
    }
</script>
    <div class="container mt-5">
        <form action="../../middleware/orders/createOrders.php"
              method="post"
              class="d-flex flex-column justify-content-center align-items-center">
            <h3>Создание</h3>
            <?php
            $a = date("Y-m-d");
            ?>
            <div class="col-3">
                <label for="start">Старт</label>
                <input id="start" name="start" type="date" value="<?php echo $a?>" min="<?php echo $a?>"  max="<?php echo $a?>" class="form-control" placeholder="Начало работы" required>
</div>
<?php
            $user = new order();
            $data = $user->Dat();
            foreach ($data as $key => $row){
            ?>
            <div class="col-3">
                <label for="service">Название услуги</label>
                <select name="service" id="service" class="form-control">
                    <option value=" "> </option>
                    <option class="form-control" value="<?php echo ['service']?>"><?php echo ['service']?></option>
                </select>
            </div>
            <div class="col-3">
                <label for="price">Стоимость</label>
                <select name="price" id="price" class="form-control">
                    <option value=" "> </option>
                    <option class="form-control" value="<?php echo ['price']?>"><?php echo ['price']?></option>
                </select>
                </div>
            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Отправить</button>
            </div>
    </div>
    <?php } ?>
</form>