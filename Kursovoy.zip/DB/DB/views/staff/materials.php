<?php
require ('../layout/header.php');
require ('../../controllers/Materials.php');
?>
<div>
    <a class="knopka" href="../auth/menu.php">В меню</a>
</div>
    <style>
        a.knopka {
            color: #fff; /* цвет текста */
            text-decoration: none; /* убирать подчёркивание у ссылок */
            background: rgb(59, 177, 173); /* фон кнопки */
            padding: .3em .8em; /* отступ от текста */
        }
        a.knopka:hover { background: rgb(97, 252, 245); } /* при наведении курсора мышки */
        a.knopka:active { background: rgb(175, 225, 224); } /* при нажатии */
    </style>
    <div class="container d-flex justify-content-between align-items-center p-2 mb-2">
        <div>
            <a class="knopka" href="create_materials.php">Добавить материалы</a>
            <a class="knopka" href="update_materials.php">Изменить материалы</a>
        </div>
    </div>
    <title>Технический отдел по ремонту техники</title>
    <div class="container mx-auto">
        <table class="table table-hover table-dark">
            <thead>
            <tr>
                <th> </th>
                <th>Название</th>
                <th>Стоимость</th>
                <th>Количество</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $db= new Materials();
            $data = $db->GetData();
            foreach ($data as $key=>$row){
                ?>
                <tr>
                    <td><?php echo ++$key;?></td>
                    <td><?php echo $row['name'];?></td>
                    <td><?php echo $row['price'];?></td>
                    <td><?php echo $row['count'];?></td>
                </tr>
            <?php }?>
            </tbody>
        </table>
    </div>
