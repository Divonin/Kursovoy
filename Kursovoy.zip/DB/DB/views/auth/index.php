<?php
require ('../layout/header.php');
require_once ('../../controllers/Services.php');
$db= new Services();
?>
<html>
<head>
    <script lang="javascript" type="text/javascript"></script>
</head>
<script src="../../public/js/main.js"></script>
<body>
<?php
if(isset($_GET['message'])){
    echo $_GET['message'];
}
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <a class="knopka" href="menu2.php">Мои заказы</a>
    <div>
        <form action="../../middleware/auth/logout.php" method="post">
            <button class="btn btn-primary" type="submit"  onclick="document.location.replace('../../middleware/auth/logout.php');">Выход</button>
        </form>
    </div>
</div>
<form action="../../middleware/order/createOrders.php" method="post">
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Services();
        $data = $user->getData();
        foreach ($data as $key => $row) {
            ?>
                       <div>
                <figure class="snip1336">
                    <figcaption>
                        <h4><?php echo $row['service']; ?><span>"Печка, утюг и другие"</span></h4>
                        <p>Сроки:<?php echo $row['deadlines']; ?> </p>
                        <p>Стоимость:<?php echo $row['price']; ?></p>
                        <a href="../orders/create.php" class="info">Заказать</a>
                    </figcaption>
                </figure>
            </div>
<?php } ?>
</form>
<script>function testJS()</script>