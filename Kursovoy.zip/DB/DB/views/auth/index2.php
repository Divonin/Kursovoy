<!-- Для сотрудников -->
<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
$db = new Orders();
?>
<body>
<?php
if(isset($_GET['message'])){
    echo $_GET['message'];
}
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div>
        <a class="knopka" href="menu.php">Действия с заказами</a>
    </div>
<form action="../../middleware/auth/logout.php" method="post">
    <button class="btn btn-primary" type="submit"  onclick="document.location.replace('../../middleware/auth/logout.php');">Выход</button>
</form>
</div>
    <table class="table table-hover table-dark">
        <thead>
        <tr>
            <th> </th>
            <th>Начало</th>
            <th>Окончание</th>
            <th>Название услуги</th>
            <th>Стоимость</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $data = $db->get();
        foreach ($data as $key=>$row){
            ?>
            <tr>
                <td><?php echo ++$key;?></td>
                <td><?php echo $row['start'];?></td>
                <td><?php echo $row['end'];?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['price'];?></td>
            </tr>
        <?php }?>
        </tbody>
    </table>