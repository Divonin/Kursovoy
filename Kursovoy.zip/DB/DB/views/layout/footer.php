<!doctype html>
<html lang="ru">
<div style="background-color: #60ee9f">
    <label>Телефон:88005553535</label>
</div>
</html>