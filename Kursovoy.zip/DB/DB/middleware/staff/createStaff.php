<?php
require('../../controllers/Orders.php');
$db = new Orders();
$start = $_POST['start'];
$end = $_POST['end'];
$name = $_POST['name'];
$price = $_POST['price'];

$response = $db->createOrders(json_encode([
    'start'=>$start,
    'end'=>$end,
    'name'=>$name,
    'price'=>$price,
]));

header('Location: ../../views/auth/menu.php?message='.json_decode($response)->message);