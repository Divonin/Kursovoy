<?php
require_once('../../controllers/Materials.php');
$db = new Materials();
$id_materials = $_POST['id_materials'];
$name = $_POST['name'];
$price = $_POST['price'];
$count = $_POST['count'];

$res = $db->updateMaterials(json_encode([
    'id_materials'=>$id_materials,
    'name'=>$name,
    'price'=>$price,
    'count'=>$count,
]));

header('Location: ../../views/staff/materials.php?message='.json_decode($res)->message);
