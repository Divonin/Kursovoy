<?php
require ('db.php');
class Team extends db
{
public function gett(){
    return $this->DBAll('Select * from team');
}
    public function createTeam($request){
        $req = json_decode($request);
        $name_team = $req->name_team;
        $sostav = $req->sostav;
        $FIO = $req->FIO;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO team (name_team,sostav,FIO) values ('{$name_team}','{$sostav}','{$FIO}')");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга добавлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}