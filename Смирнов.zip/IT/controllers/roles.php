<?php

require('db.php');

class roles extends DB
{
    public function login($request)
    {
        $req = json_decode($request);
        $FIO = $req->FIO;
        $mail = $req->mail;
        $password = $req->password;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from users where FIO=:FIO and mail=:mail and password=:pass');
        $sql->execute([
            'FIO' => $FIO,
            'mail' => $mail,
            'pass' => $password,
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'FIO' => $data->FIO,
                'mail' => $data->mail,
                'role' => $data->role
            ];
        }
    }

    public function registration($request)
    {
        $req = json_decode($request);
        $FIO = $req->FIO;
        $mail = $req->mail;
        $password = $req->password;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from users where FIO=:FIO and mail=:mail and password=:pass');
        $sql->execute(array(
            'FIO' => $FIO,
            'mail' => $mail,
            'pass' => $password,
        ));
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            return json_encode([
                'message' => "Такой пользователь существует"
            ]);
        }
        $sql = $connect->prepare("INSERT INTO users(FIO,mail,password,role) values (:FIO,:mail,:pass,:role)");
        $sql->execute([
            'FIO' => $FIO,
            'mail' => $mail,
            'pass' => $password,
            "role" => 3
        ]);
        $sql = $connect->prepare('SELECT * from users where FIO=:FIO and mail=:mail and password=:pass');
        $sql->execute([
            'FIO' => $FIO,
            'mail' => $mail,
            'pass' => $password,
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'FIO' => $data->FIO,
                'mail' => $data->mail,
                'role' => $data->role
            ];
            return json_encode([
                'message' => 'Пользователь добавлен'
            ]);
        }
    }
}