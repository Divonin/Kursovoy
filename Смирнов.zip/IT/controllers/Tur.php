<?php
require ('db.php');
class Tur extends db
{
public function get(){
    return $this->DBAll('Select * from tournaments');
}
    public function getM(){
        return $this->DBAll('Select * from tournaments WHERE category="Мальчики"');
    }
    public function getG(){
        return $this->DBAll('Select * from tournaments WHERE category="Девочки"');
    }
    public function createTour($request){
        $req = json_decode($request);
        $title = $req-> title;
        $description = $req-> description;
        $Address_sportcomplex = $req-> Address_sportcomplex;
        $category = $req->category;
        $date = $req->date;
        $name_team = $req->name_team;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO tournaments (title,description,Address_sportcomplex, category,date,name_team)
values ('{$title}','{$description}','{$Address_sportcomplex}','{$category}','{$date}','{$name_team}')");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга добавлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function deleteTour($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE FROM tournaments WHERE id='.$req->id,
            'Услуга удалена');
    }
    public function updateTour($request){
        $req = json_decode($request);
        $id = $req->id;
        $title = $req-> title;
        $description = $req-> description;
        $Address_sportcomplex = $req-> Address_sportcomplex;
        $category = $req->category;
        $date = $req->date;
        $name_team = $req->name_team;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE tournaments SET title='{$title}', description='{$description}', Address_sportcomplex='{$Address_sportcomplex}',
                    category='{$category}', date='{$date}', name_team='{$name_team}' WHERE id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Услуга обновлена'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}