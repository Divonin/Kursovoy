<?php
require('../../controllers/Team.php');
$db = new Team();
$name_team = $_POST['name_team'];
$sostav = $_POST['sostav'];
$FIO = $_POST['FIO'];

$response = $db->createTeam(json_encode([
    'name_team'=>$name_team,
    'sostav'=>$sostav,
    'FIO'=>$FIO,
]));

header('Location: ../../views/user/index2.php?message='.json_decode($response)->message);