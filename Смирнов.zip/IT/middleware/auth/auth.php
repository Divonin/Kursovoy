<?php
require('../../controllers/roles.php');
$db = new roles();
$FIO = $_POST['FIO'];
$mail = $_POST['mail'];
$password = $_POST['password'];

$db->login(json_encode([
    'FIO'=>$FIO,
    'mail'=>$mail,
    'password'=>$password,
]));
session_start();
if($_SESSION['user']->role===3) {
    header('Location: ../../views/user/index2.php');
}
if($_SESSION['user']->role===1) {
    header('Location: ../../views/org/index.php');
}