<?php
require('../../controllers/roles.php');
$db = new roles();
$FIO = $_POST['FIO'];
$mail = $_POST['mail'];
$password = $_POST['password'];

$response = $db->registration(json_encode([
    'FIO'=>$FIO,
    'mail'=>$mail,
    'password'=>$password,
]));

header('Location: ../../views/auth/auth.php');