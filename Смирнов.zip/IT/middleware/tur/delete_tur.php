<?php
require('../../controllers/Tur.php');
$db = new Tur();
$id=$_POST['id'];

$response = $db->deleteTour(json_encode([
    'id'=>$id,
]));

header('Location: ../../views/org/index.php?message='.json_decode($response)->message);