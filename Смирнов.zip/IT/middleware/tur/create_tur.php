<?php
require('../../controllers/Tur.php');
$db = new Tur();
$title = $_POST['title'];
$description = $_POST['description'];
$Address_sportcomplex = $_POST['Address_sportcomplex'];
$category = $_POST['category'];
$date = $_POST['date'];
$name_team = $_POST['name_team'];

$response = $db->createTour(json_encode([
    'title'=>$title,
    'description'=>$description,
    'Address_sportcomplex'=>$Address_sportcomplex,
    'category'=>$category,
    'date'=>$date,
    'name_team'=>$name_team,
    ]));

header('Location: ../../views/org/index.php?message='.json_decode($response)->message);