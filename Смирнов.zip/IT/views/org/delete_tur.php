<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="index.php">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
            <img src="../../views/layout/img/logo.png" alt="score" class="logo">
        </div>
    </div>
</header>
<?php
require_once ('../../controllers/Tur.php');
?>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Tur();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Название: </span>
                        <span class="card-text"><?php echo $row['title'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Описание: </span>
                        <span class="card-text"><?php echo $row['description'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Адрес: </span>
                        <span class="card-text"><?php echo $row['Address_sportcomplex'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Категория: </span>
                        <span class="card-text"><?php echo $row['category'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Дата: </span>
                        <span class="card-text"><?php echo $row['date'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Команды: </span>
                        <span class="card-text"><?php echo $row['name_team'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/tur/delete_tur.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Отменить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>