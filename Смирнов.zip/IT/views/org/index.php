<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="container">
        <div class="heading">
            <img src="../layout/img/logo.png" alt="score" class="logo">
            <nav>
                <ul class="menu">
                    <li>
                        <a href="cat.php">Категории</a><!--Сделано-->
                    </li>
                    <li>
                        <a href="tur.php">Турниры</a><!--Сделано-->
                    </li>
                    <li>
                        <a href="teams.php">Команды</a><!--Сделано-->
                    </li>
                    <li>    <div>
                            <form action="../../middleware/auth/logout.php" method="post">
                                <button class="btn btn-primary" type="submit"  onclick="document.location.replace('../../middleware/auth/logout.php');">Выход</button>
                            </form>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="titles">
            <div class="titles_first">
                Турниры по баскетболу
            </div>
            <h1>
                Учавствуй и побеждай!
            </h1>
            <div class="btn-group">
                <a href="create_tur.php">СОЗДАТЬ ТУРНИР</a><!--Для Организатора-->
            </div>
            <div class="btn-group">
                <a href="update_tur.php">РЕДАКТИРОВАТЬ ТУРНИР</a><!--Для Организатора-->
            </div>
            <div class="btn-group">
                <a href="delete_tur.php">ОТМЕНИТЬ ТУРНИР</a><!--Для Организатора-->
            </div>
        </div>
    </div>
</header>

<footer>
    <div class="container">

    </div>
</footer>

</body>
</html>
