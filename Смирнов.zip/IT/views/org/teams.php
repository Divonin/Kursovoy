<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="index.php">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
            <img src="../layout/img/logo.png" alt="score" class="logo">
            <?php
            require ('../../controllers/Team.php');
            ?>    </div>
</header>
            <section class="container">
                <div style="text-align: center;">
                    <table class="table table-hover table-warning">
                        <thead>
                        <th>Название</th>
                        <th>Состав</th>
                        <th>Тренер</th>
                        </thead>
                        <tbody>
                        <?php
                        $db = new Team();
                        $data=$db->gett();
                        foreach ($data as $key => $row){
                            ?>
                            <tr>
                                <td><?php echo $row['name_team']?></td>
                                <td><?php echo $row['sostav']?></td>
                                <td><?php echo $row['FIO']?></td>
                            </tr>
                        <?php }?>
                        </tbody>
                    </table>
        </div>
        </section>
</body>