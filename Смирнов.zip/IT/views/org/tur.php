<?php
require ('../../controllers/Tur.php');
$db=new Tur();
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="index.php">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
            <img src="../../views/layout/img/logo.png" alt="score" class="logo">
        </div>
    </div>
</header>
<table class="table table-hover table-warning">
    <thead>
    <th>Название</th>
    <th>Описание</th>
    <th>Адрес</th>
    <th>Дата</th>
    <th>Команды</th>
    </thead>
    <tbody>
    <?php
    $data=$db->get();
    foreach ($data as $key => $row){
    ?>
    <tr>
        <td><?php echo $row['title']?></td>
        <td><?php echo $row['description']?></td>
        <td><?php echo $row['Address_sportcomplex']?></td>
        <td><?php echo $row['date']?></td>
        <td><?php echo $row['name_team']?></td>
    </tr>
    <?php }?>
    </tbody>
</table>
</body>
