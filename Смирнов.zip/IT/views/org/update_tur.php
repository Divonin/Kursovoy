<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="index.php">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
            <img src="../../views/layout/img/logo.png" alt="score" class="logo">
        </div>
    </div>
</header>
  <?php
require_once ('../../controllers/Tur.php');
$db = new Tur();
?>
<table class="table table-hover table-info">
    <thead>
    <tr>
        <th> </th>
        <th>Название</th>
        <th>Описание</th>
        <th>Адрес</th>
        <th>Дата</th>
        <th>Команды</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->get();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/tur/update_tur.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row["id"]; ?>" class="form-control" hidden
                           required>
                </td>
                <td>
                    <input id="title" name="title" type="text" value="<?php echo $row["title"]; ?>" class="form-control"
                           required>
                </td>
                <td>
                    <input id="description" name="description" type="text"
                           value="<?php echo $row["description"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="Address_sportcomplex" name="Address_sportcomplex" type="text"
                           value="<?php echo $row["Address_sportcomplex"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="date" name="date" type="text"
                           value="<?php echo $row["date"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="name_team" name="name_team" type="text" value="<?php echo $row["name_team"]; ?>"
                           class="form-control" required>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>