<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="index.php">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
            <img src="../../views/layout/img/logo.png" alt="score" class="logo">
<?php
require ('../../controllers/Tur.php');
?>
<div class="container mt-5">
    <form action="../../middleware/tur/create_tur.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-3">
            <label for="title">Название</label>
            <input id="title" name="title" type="text" class="form-control" placeholder="Название" required>
        </div>
        <div class="col-3">
            <label for="description">Описание</label>
            <input id="description" name="description" type="text" class="form-control" placeholder="Описание" required>
        </div>
        <div class="col-3">
            <label for="Address_sportcomplex">Адрес</label>
            <input id="Address_sportcomplex" name="Address_sportcomplex" type="text" class="form-control" placeholder="Адрес" required>
        </div>
        <div class="col-3">
            <label for="category">Категория</label>
            <input id="category" name="category" type="text" class="form-control" placeholder="Категория" required>
        </div>
        <?php
        $a = date("Y-m-d");
        ?>
        <div class="col-3">
            <label for="date">Дата</label>
            <input id="date" name="date" type="date" min="<?php echo $a?>" class="form-control" required>
        </div>
        <div class="col-3">
            <label for="name_team">Команды</label>
            <input id="name_team" name="name_team" type="text" class="form-control" placeholder="Команды" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div>
        </div>
    </div>
</header>
