<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="container">
        <div class="heading">
            <img src="../layout/img/logo.png" alt="score" class="logo">
            <nav>
                <ul class="menu">
                    <li>
                        <a href="cat.php">Категории</a><!--Сделано-->
                    </li>
                    <li>
                        <a href="tur.php">Турниры</a><!--Сделано-->
                    </li>
                    <li>    <div>
                            <form action="../../middleware/auth/logout.php" method="post">
                                <button class="btn btn-primary" type="submit"  onclick="document.location.replace('../../middleware/auth/logout.php');">Выход</button>
                            </form>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="titles">
            <div class="titles_first">
                Турниры по баскетболу
            </div>
            <h1>
                Учавствуй и побеждай!
            </h1>
            <div class="btn-group">
                <a href="create_team.php">СОЗДАТЬ КОМАНДУ</a><!--Для Пользователя-->
            </div>
        </div>
    </div>
</header>


<section>
    <div class="container">

    </div>

</section>

<footer>
    <div class="container">

    </div>
</footer>

</body>
</html>