<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="index2.php">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
                        <img src="../layout/img/logo.png" alt="score" class="logo">
            <?php
            require ('../../controllers/Team.php');
            ?>
            <div class="container mt-5">
    <form action="../../middleware/team/create_team.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-3">
            <label for="name_team">Команда</label>
            <input id="name_team" name="name_team" type="text" class="form-control" placeholder="Команда" required>
        </div>
        <div class="col-3">
            <label for="sostav">Состав</label>
            <textarea id="sostav" name="sostav" type="text" class="form-control" rows="5" cols="15" placeholder="Состав" required></textarea>
        </div>
        <div class="col-3">
            <label for="FIO">ФИО тренера</label>
            <select name="FIO" id="FIO" class="form">
                <option value="">Выберете тренера</option>
                <option value="Козлов Дмитрий Витальевич">Козлов Дмитрий Витальевич</option>
                <option value="Иванов Иван Дмитриевич">Иванов Иван Дмитриевич</option>
                <option value=""></option>
                <option value=""></option>
                <option value=""></option>
                <option value=""></option>
            </select>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div>
</div>
</div>
</header>