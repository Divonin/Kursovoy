<?php
require('../../controllers/roles.php');
$db= new roles();
?>
<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div>
        <div class="heading">
            <img src="../layout/img/logo.png" alt="score" class="logo">
<div class="btn-groups">
    <a href="../../index.html">На главную</a>
</div>
<div class="d-flex flex-column justify-content-center align-items-center">
    <h3 style="color: #0dcaf0;">Авторизация</h3>
</div>
<form action="../../middleware/auth/auth.php" method="post" class="d-flex flex-column justify-content-center align-items-center">
    <div class="col-2">
        <label for="FIO" style="color: #0dcaf0;">ФИО</label>
        <input id="FIO" name="FIO" type="text" class="form-control"  aria-describedby="emailHelp" placeholder="Фамилия" required>
    </div>
    <div class="col-2">
        <label for="mail" style="color: #0dcaf0;">Mail</label>
        <input id="mail" name="mail" type="text" class="form-control" aria-describedby="emailHelp" placeholder="Имя" required>
    </div>
    <div class="password">
        <label for="password" style="color: #0dcaf0;">пароль</label>
        <input id="password-input" name="password" type="password" class="form-control" placeholder="Введите пароль" required>
        <a href="#" class="password-control"></a>
    </div>
    <script src="https://snipp.ru/cdn/jquery/2.1.1/jquery.min.js"></script>
    <script>
        $('body').on('click', '.password-control', function(){
            if ($('#password-input').attr('type') == 'password'){
                $(this).addClass('view');
                $('#password-input').attr('type', 'text');
            } else {
                $(this).removeClass('view');
                $('#password-input').attr('type', 'password');
            }
            return false;
        });
    </script>
    <button type="submit" class="btn btn-primary">Вход</button>
    <div>
        <a href="registration.php" class="btn btn-outline-info">Не зарегистрированы?</a>
    </div>
</form>
        </div>
    </div>
</header>
</body>