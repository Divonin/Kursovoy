<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Баскетбольчик</title>
    <link rel="stylesheet" href="../../public/css/bootstrap.css">
    <link rel="stylesheet" href="../layout/css/main.css">
    <link rel="shortcut icon" href="../layout/img/zagolovok.jpg"/>
</head>
<body>
<header>
    <div class="btn-groups">
        <a href="../../index.html">На главную</a>
    </div>
    <div class="container">
        <div class="heading">
            <img src="../../views/layout/img/logo.png" alt="score" class="logo">
            </div>
    </div>
</header>

<section class="container d-flex">
        <div style="text-align: center; margin: 70px 0 0 200px;">
        <table class="table table-hover table-light" style="display: inline-block;">
            <thead>
            <th style="size: ledger; outline-color: #101214;outline: auto"><img  class="logot" src="../../views/layout/img/malchik.png" alt="score">Юноши</th>
            </thead>
            <tbody>
            <tr>
                <td style=" outline-color: #101214; outline: auto">
                    <div>
                        <a class="btn btn-info" href="cat_man.php">Показать</a>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
    <div style="text-align: center; margin: 70px 0 0 350px;"">
        <table class="table table-hover table-light" style="display: inline-block;">
            <thead>
            <th style="size: ledger; outline-color: #101214;outline: auto"><img  class="logot" src="../../views/layout/img/devochka.png" alt="score">Девочки</th>
            </thead>
            <tbody>
            <tr>
                <td style=" outline-color: #101214; outline: auto">
                    <div>
                        <a class="btn btn-info" href="cat_girl.php">Показать</a>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</section>

<footer>
    <div class="container">

    </div>
</footer>

</body>