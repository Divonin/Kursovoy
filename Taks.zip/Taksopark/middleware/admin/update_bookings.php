<?php
require ('../../controllers/Bokings.php');
$db = new Bokings();
$id = $_POST['id'];
$price = $_POST['price'];
$status = $_POST['status'];
$car = $_POST['car'];
$res = $db ->updateB(json_encode([
    'id'=>$id,
    'price'=>$price,
    'status'=>$status,
    'car'=>$car,
]));
header('Location: ../../views/admin/index.php?message='. json_decode($res)->message);