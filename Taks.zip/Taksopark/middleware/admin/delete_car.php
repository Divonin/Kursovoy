<?php
require_once ('../../controllers/Cars.php');
$db = new Cars();
$id = $_POST['id'];

$res = $db->delete(json_encode([
    'id'=>$id
]));

header('Location: ../../views/admin/cars.php?message='. json_decode($res)->message);