<?php
require ('../../controllers/Cars.php');
$db = new Cars();
$model = $_POST['model'];
$vin = $_POST['vin'];
$license_plate = $_POST['license_plate'];

$res = $db ->create(json_encode([
    'model'=>$model,
    'vin'=>$vin,
    'license_plate'=>$license_plate,
]));
header('Location: ../../views/admin/cars.php?message='. json_decode($res)->message);