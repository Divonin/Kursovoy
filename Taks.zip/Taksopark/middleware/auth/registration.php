<?php
require('../../controllers/roles.php');
$db = new roles();
$login = $_POST['login'];
$email = $_POST['email'];
$password = $_POST['password'];

$response = $db->registration(json_encode([
    'login' => $login,
    'email' => $email,
    'password'=>$password,
]));

header('Location: ../../views/auth/auth.php');