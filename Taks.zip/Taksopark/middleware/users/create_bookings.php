<?php
require ('../../controllers/Bokings.php');
$db = new Bokings();
$pickup_adress = $_POST['pickup_adress'];
$droff_adress = $_POST['droff_adress'];
$price = $_POST['price'];
$pay_method = $_POST['pay_method'];
$status = $_POST['status'];
$car = $_POST['car'];
$res = $db ->create(json_encode([
    'pickup_adress'=>$pickup_adress,
    'droff_adress'=>$droff_adress,
    'price'=>$price,
    'pay_method'=>$pay_method,
    'status'=>$status,
    'car'=>$car,
]));
header('Location: ../../views/users/index.php?message='. json_decode($res)->message);