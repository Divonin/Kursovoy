<?php
require ('views/layout/header.php');
?>
    <div style="background-color: yellowgreen;height: 30px; box-shadow: 0 0 10px black;">
    <div class="buttones">
        <a class="knopka" href="/views/auth/auth.php">Авторизация</a>
    </div>
</div>
<?php
if (isset($_GET['message'])) {
    echo $_GET['message'];
}
?>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <div class="card m-2 shadow">
            <div class="card-body">
        <div style="background: yellowgreen">
            <p style="text-align: center;" ><img src="images/pngwing.com%20(1).png" alt="" width="350"></p>
            <p style="margin: 0;padding: 0;font-size: 25pt; text-align: center">"Современные авто"</p>
        </div>
    </div>
</div>
</div>
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <div class="card m-2 shadow">
            <div class="card-body">
                <div style="background: yellowgreen">
                    <p  style="text-align: center;"><img style="margin: 0;padding: 0;font-size: 25pt;" src="images/pngwing.com%20(2).png" alt="" width="150"></p>
                    <p style="margin: 0;padding: 0;font-size: 25pt; text-align: center">"Лучшие водители"</p>
                </div>
            </div>
        </div>
    </div>
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <div class="card m-2 shadow">
            <div class="card-body">
                <div style="background: yellowgreen">
                    <p  style="text-align: center;"><img style="margin: 0;padding: 0;font-size: 25pt;" src="images/pngwing.com%20(3).png" alt="" width="150"></p>
                    <p style="margin: 0;padding: 0;font-size: 25pt; text-align: center">"Безопасные и быстрые поездки"</p>
                </div>
            </div>
        </div>
    </div>
</div>