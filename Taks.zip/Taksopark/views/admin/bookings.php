<?php
require ('../layout/header.php');
require ('../../controllers/Bokings.php');
$db=new Bokings();
?>
<div>
    <a class="knopka" href="index.php">На главную</a>
    <a class="knopka" href="update_bookings.php">Изменить данные о заказе</a>
</div>
<table class="table table-info">
    <thead>
    <tr>
        <th> </th>
        <th>Начальный адресс</th>
        <th>Конечный адресс</th>
        <th>Цена</th>
        <th>Метод оплаты</th>
        <th>Статус</th>
        <th>Машина</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data=$db->Det();
    foreach ($data as $key => $row){
        ?>
        <tr>
            <form action="../../middleware/admin/update_bookings.php" method="post">
                <td><?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row['id']?>"  hidden required>
                </td>
                <td><?php echo $row['pickup_adress']?></td>
                <td><?php echo $row['droff_adress']?></td>
                <td><?php echo $row['price']?></td>
                <td><?php echo $row['pay_method']?></td>
                <td><?php echo $row['status']?></td>
                <td><?php echo $row['car']?></td>
            <td>
                <button class="btn btn-danger" type="submit">Удалить</button>
            </td>
            </form>
        </tr>
    <?php }?>
    </tbody>
</table>