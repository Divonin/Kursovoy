<?php
require ('../../views/layout/header.php');
require ('../../controllers/Cars.php');
?>

    <div style="background-color: yellowgreen;height: 30px; box-shadow: 0 0 10px black;">
        <div class="buttonese">
            <a class="knopka" href="index.php">Главная</a>
            <a class="knopka" href="cars.php">Машины</a>
            <a class="knopka" href="create_car.php">Добавить машину</a>
            <a class="knopka" href="delete_car.php">Удалить машину</a>
        </div>
    </div>
<?php
if (isset($_GET['message'])) {
    echo $_GET['message'];
}
?>
<?php
$user = new Cars();
$data = $user->get();
foreach ($data as $key => $row) {
    ?>
    <div class="container mx-auto">
        <div style="display: grid; grid-template-columns: repeat(2,1fr)">
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div style="background: yellowgreen">
                        <p style="margin: 0;padding: 0;font-size: 25pt; text-align: center">"Авто"</p>
                        <p style="font-size: 15pt"> Машина: <?php echo $row['model']?></p>
                        <p style="font-size: 15pt"> VIN: <?php echo $row['vin']?></p>
                        <p style="font-size: 15pt"> Номер: <?php echo $row['license_plate']?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php } ?>