<?php
require ('../../views/layout/header.php');
require ('../../controllers/Cars.php');
?>
<div>
    <a class="knopa" href="cars.php">Главная</a>
</div>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Cars();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Название: </span>
                        <span class="card-text"><?php echo $row['model'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Кол-во: </span>
                        <span class="card-text"><?php echo $row['vin'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Статус: </span>
                        <span class="card-text"><?php echo $row['license_plate'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/admin/delete_car.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
