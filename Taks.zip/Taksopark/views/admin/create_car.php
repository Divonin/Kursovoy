<?php
require ('../../views/layout/header.php');
require ('../../controllers/Cars.php');
?>
<div style="background-color: yellowgreen;height: 30px; box-shadow: 0 0 10px black;">
    <div class="buttones">
        <a class="knopka" href="index.php">Главная</a>
    </div>
</div>
<div class="container mt-5">
    <form action="../../middleware/admin/create_car.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>

        <div class="col-3">
            <label for="model">Модель</label>
            <input id="model" name="model" type="text" class="form-control" placeholder="Модель"  required>
        </div>
        <div class="col-3">
            <label for="vin">vin</label>
            <input id="vin" name="vin" type="text" class="form-control" placeholder="VIN" required>
        </div>
        <div class="col-3">
            <label for="license_plate">Номер</label>
            <input id="license_plate" name="license_plate" type="text" class="form-control" placeholder="Номер" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div