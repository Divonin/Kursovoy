<?php
require ('../layout/header.php');
require ('../../controllers/Bokings.php');
$db=new Bokings();
?>
<div>
    <a class="knopa" href="index.php">На главную</a>
</div>
<table class="table table-info">
    <thead>
    <tr>
        <th> </th>
        <th>Начальный адресс</th>
        <th>Конечный адресс</th>
        <th>Цена</th>
        <th>Метод оплаты</th>
        <th>Статус</th>
        <th>Машина</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data=$db->Det();
    foreach ($data as $key => $row){
        ?>
        <tr>
            <form action="../../middleware/admin/update_bookings.php" method="post">
                <td><?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row['id']?>"  hidden required>
                </td>
                <td><?php echo $row['pickup_adress']?></td>
                <td><?php echo $row['droff_adress']?></td>
                <td>
                    <input id="price" name="price" type="text" value="<?php echo $row['price']?>" class="form-control" required>
                </td>
                <td><?php echo $row['pay_method']?></td>
                <td>
                    <input id="status" name="status" type="text" value="<?php echo $row['status']?>" class="form-control" required>
                </td>
                <td>
                    <input id="car" name="car" type="text" value="<?php echo $row['car']?>" class="form-control" >
                </td>
                <td>
                    <button class="btn btn-primary" type="submit">Изменить</button>
                </td>
            </form>
        </tr>
    <?php }?>
    </tbody>
</table>
