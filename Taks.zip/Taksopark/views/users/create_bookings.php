<?php
require ('../layout/header.php');
require ('../../controllers/Bokings.php');
?>
<div>
    <a class="knopa" href="index.php">Главная</a>
</div>
<div class="container mt-5">
    <form action="../../middleware/users/create_bookings.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <div class="col-3">
            <label for="pickup_adress">Начальный адресс</label>
            <input id="pickup_adress" name="pickup_adress" type="text" class="form-control" placeholder="Начальный адресс" required>
        </div>
        <div class="col-3">
            <label for="droff_adress">Конечный адресс</label>
            <input id="droff_adress" name="droff_adress" type="text" class="form-control" placeholder="Конечный адресс" required>
        </div>
        <div class="col-3">
            <label for="pay_method">Метод оплаты</label>
            <select name="pay_method" id="pay_method" class="form-control" required>
                <option value=""> </option>
                <option value="Наличные">Наличные</option>
                <option value="Карта">Карта</option>
            </select>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div>