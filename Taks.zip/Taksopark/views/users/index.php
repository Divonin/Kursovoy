<?php
require ('../../views/layout/header.php');
require ('../../controllers/Cars.php');
?>
<div style="background-color: yellowgreen;height: 50px; box-shadow: 0 0 10px black;">
    <div class="buttones">
        <a class="knopka" href="create_bookings.php">Забронировать авто</a>
    </div>
</div>
    <div style="  list-style-type: none;
  padding-left: 1600px;
  margin-bottom: 0;">
    <form action="../../middleware/auth/logout.php" method="post">
        <button class="btn btn-light" type="submit"  onclick="document.location.replace('middleware/auth/logout.php');">Выход</button>
    </form>
    </div>
<?php
if (isset($_GET['message'])) {
    echo $_GET['message'];
}
?>
<?php
$user = new Cars();
$data = $user->get();
foreach ($data as $key => $row) {
?>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(2,1fr)">
        <div class="card m-2 shadow">
            <div class="card-body">
        <div style="background: yellowgreen">
            <p style="text-align: center;" ><img src="../../images/pngwing.com%20(1).png" alt="" width="350"></p>
            <p style="margin: 0;padding: 0;font-size: 25pt; text-align: center">"Современные авто"</p>
            <p style="font-size: 15pt"> Машина: <?php echo $row['model']?></p>
            <p></p>
        </div>
    </div>
</div>
</div>
</div>
<?php } ?>