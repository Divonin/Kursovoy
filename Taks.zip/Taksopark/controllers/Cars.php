<?php
require ('db.php');
class Cars extends  DB
{
public function get(){
    return $this->DBAll('SELECT * FROM cars');
}
    public function delete($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from cars where id='.$req->id,
            'Авто удален');
    }
    public function create($request){
        $req = json_decode($request);
        $model = $req->model;
        $vin = $req->vin;
        $license_plate=$req->license_plate;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO cars (model, vin, license_plate) value ('{$model}','{$vin}','{$license_plate}')");
            $connect->commit();
            return json_encode([
                'message'=>'Авто добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}