<?php
require ('db.php');
class Bokings extends DB
{
    public function Det(){
        return $this->DBAll('SELECT * FROM bookings');
    }
    public function delete($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from bookings where id='.$req->id,
            'Бронь удалена');
    }
    public function create($request){
        $req = json_decode($request);
        $pickup_adress = $req->pickup_adress;
        $droff_adress = $req->droff_adress;
        $price=$req->price;
        $pay_method = $req->pay_method;
        $status = $req->status;
        $car=$req->car;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO bookings (pickup_adress, droff_adress, price, pay_method, status, car)
    value ('{$pickup_adress}','{$droff_adress}','{$price}','{$pay_method}','{$status}','{$car}')");
            $connect->commit();
            return json_encode([
                'message'=>'Авто добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateB($request){
        $req = json_decode($request);
        $id = $req->id;
        $price=$req->price;
        $status = $req->status;
        $car=$req->car;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("update bookings set price='{$price}', status='{$status}', car='{$car}' where id={$id}");
            $connect->commit();
            return json_encode([
                'message'=>'Авто добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}