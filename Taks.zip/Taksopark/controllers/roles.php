<?php
require ('db.php');
class roles extends db
{
    public function login($request)
    {
        $req = json_decode($request);
        $login = $req->login;
        $email = $req->email;
        $password = $req->password;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from users where login=:login and email=:email and password=:pass');
        $sql->execute([

            'login' => $login,
            'email' => $email,
            'pass' => $password,
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'login' => $data->login,
                'email' => $data->email,
                'role' => $data->role
            ];
        }
    }

    public function registration($request)
    {
        $req = json_decode($request);
        $login = $req->login;
        $email = $req->email;
        $password = $req->password;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from users where login=:login and email=:email and password=:pass');
        $sql->execute(array(
            'login' => $login,
            'email' => $email,
            'pass' => $password,
        ));
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            return json_encode([
                'message' => "Такой пользователь существует"
            ]);
        }

        $sql = $connect->prepare("INSERT INTO users(login, email,password,role) values (:login,:email,:pass,:role)");
        $sql->execute([
            'login' => $login,
            'email' => $email,
            "pass" => $password,
            "role" => 3
        ]);

        $sql = $connect->prepare('SELECT * from users where login=:login and email=:email and password=:pass');
        $sql->execute([
            'login' => $login,
            'email' => $email,
            'password' => $password,
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'login' => $data->login,
                'email' => $data->email,
                'role' => $data->role
            ];
            return json_encode([
                'message' => 'Пользователь добавлен'
            ]);
        }}
}