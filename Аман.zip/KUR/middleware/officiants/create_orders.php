<?php
require('../../controllers/Orders.php');
$db = new Orders();
$date = $_POST['date'];
$name_dish = $_POST['name_dish'];
$price = $_POST['price'];

$response = $db->createOrders(json_encode([
    'date'=>$date,
    'name_dish'=>$name_dish,
    'price'=>$price,
]));

header('Location: ../../views/auth/menu.php?message='.json_decode($response)->message);
