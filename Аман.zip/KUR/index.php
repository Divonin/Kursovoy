<?php
require_once ('views/layout/header.php');
require('controllers/Menu.php');
?>
<div class="border_width">
    <div>
        <a class="knopka" href="/index.php">Главная страница</a>
    </div>
    <!doctype html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="/public/css/bootstrap.css">
    </head>
    <body>
    <?php
    if(isset($_GET['message'])){
        echo $_GET['message'];
    }
    ?> </body>
    <div class="container d-flex justify-content-between align-items-center p-4 mb-auto ">
        <div>
            <a class="knopka" href="/views/auth/auth.php">Авторизация</a>
        </div>
        <div>
            <a class="knopka" href="/views/auth/registration.php">Регистрация</a>
        </div>
    </div>
</div>
<div class="container mx-auto ">
    <table class="table table-hover table-info">
        <thead>
        <tr>
            <th> </th>
            <th>Название</th>
            <th>Описание</th>
            <th>Стоимость</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $db= new Menu();
        $data = $db->getdata();
        foreach ($data as $key=>$row){
            ?>
            <tr>
                <td><?php echo ++$key;?></td>
                <td><?php echo $row['name'];?></td>
                <td><?php echo $row['description'];?></td>
                <td><?php echo $row['price'];?></td>
            </tr>
        <?php }?>
        </tbody>
    </table>
</div>