<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Staff.php');
?>
<div>
    <a class="knopka" href="menu.php">Назад</a>
</div>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Staff();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Фамилия: </span>
                        <span class="card-text"><?php echo $row['last_name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Имя: </span>
                        <span class="card-text"><?php echo $row['name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Отчество: </span>
                        <span class="card-text"><?php echo $row['father_name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Стаж: </span>
                        <span class="card-text"><?php echo $row['experience'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">ЗП: </span>
                        <span class="card-text"><?php echo $row['wages'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/admin/delete_staff.php" method="post">
                            <input name="id_staff" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
