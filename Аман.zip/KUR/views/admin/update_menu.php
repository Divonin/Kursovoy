<?php
require_once('../layout/header.php');
require_once('../../controllers/Menu.php');
$db = new Menu();
?>
<div>
    <a class="knopka" href="menu.php">Назад</a>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th>id</th>
        <th>Название</th>
        <th>Описание</th>
        <th>Цена</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->getData();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/admin/update_menu.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row["id"]; ?>" class="form-control" hidden required>
                </td>
                <td>
                    <input id="name" name="name" type="text" value="<?php echo $row["name"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="description" name="description" type="text" value="<?php echo $row["description"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="price" name="price" type="text" value="<?php echo $row["price"]; ?>" class="form-control" required>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>

