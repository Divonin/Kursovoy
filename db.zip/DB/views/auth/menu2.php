<div class="d-flex">
    <a class="knopka" href="../auth/index.php">Главная страница</a>
</div>
<?php
require ('../layout/header.php');
require ('../../controllers/order.php');
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div>Заказы</div>
    <div>
        <a class="knopka" href="../orders/create.php">Добавить заказ</a>
        <a class="knopka" href="../orders/delete.php">Отменить заказ</a>
    </div>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>Начало</th>
        <th>Окончание</th>
        <th>Название услуги</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $db= new order();
    $data = $db->get();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['start'];?></td>
            <td><?php echo $row['end'];?></td>
            <td><?php echo $row['names'];?></td>
            <td><?php echo $row['price'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>
<?php
require ('../layout/footer.php');
?>
