/* Меню для сотрудников */
<div class="d-flex">
    <a class="knopka" href="../auth/index2.php">Главная страница</a>
</div>
<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
?>
<style>
    .labelore{
        color: black;
        padding: .5em 1.5em;
        background: white;
    }
</style>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div class="labelore">Заказы</div>
    <div>
        <a class="knopka" href="../staff/create.php">Добавить заказ</a>
        <a class="knopka" href="../staff/update.php">Изменить данные заказа</a>
        <a class="knopka" href="../staff/delete.php">Удалить заказ</a>
        <a class="knopka" href="../staff/equipment.php">Оборудование</a>
        <a class="knopka" href="../staff/materials.php">Материалы</a>
    </div>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>Начало</th>
        <th>Окончание</th>
        <th>Название услуги</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $db= new Orders();
    $data = $db->get();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['start'];?></td>
            <td><?php echo $row['end'];?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['price'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>