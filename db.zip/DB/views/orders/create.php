<div>
    <a class="knopka" href="../auth/menu2.php">В меню</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/order.php');
?>
<head>
    <script lang="javascript" type="text/javascript"></script>
</head>
    <div class="container mt-5">
        <form action="../../middleware/orders/createOrders.php"
              method="post"
              class="d-flex flex-column justify-content-center align-items-center">
            <h3>Создание</h3>
            <?php
            $a = date("Y-m-d");
            ?>
            <div class="col-3">
                <label for="start">Старт</label>
                <input id="start" name="start" type="date" value="<?php echo $a?>" min="<?php echo $a?>"  max="<?php echo $a?>" class="form-control" placeholder="Начало работы" required>
</div>
<?php
            ?>
            <div class="col-3">
                <label for="names">Название услуги</label>
                <select name="names" id="names" class="form-control">
                    <option value=" "> </option>
                    <option class="form-control" value="Ремонт утюга">Ремонт утюга</option>
                    <option class="form-control" value="Ремонт мультиварки">Ремонт мультиварки</option>
                    <option class="form-control" value="Ремонт холодильника">Ремонт холодильника</option>
                    <option class="form-control" value="Ремонт пылесоса">Ремонт пылесоса</option>
                    <option class="form-control" value="Ремонт стиральной машины ">Ремонт стиральной машины </option>
                    <option class="form-control" value="Ремонт телевизора">Ремонт телевизора</option>
                    <option class="form-control" value="Ремонт йогуртницы">Ремонт йогуртницы</option>
                    <option class="form-control" value="Ремонт тостера">Ремонт тостера</option>
                    <option class="form-control" value="Ремонт микроволновой печи">Ремонт микроволновой печи</option>
                    <option class="form-control" value="Ремонт фена">Ремонт фена</option>
                    <option class="form-control" value="Ремонт кухонного комбайна">Ремонт кухонного комбайна</option>
                    <option class="form-control" value="Ремонт планетарного миксера">Ремонт планетарного миксера</option>
                    <option class="form-control" value="Ремонт миксера">Ремонт миксера</option>
                    <option class="form-control" value="Ремонт чайника">Ремонт чайника</option>
                    <option class="form-control" value="Ремонт электрической плиты">Ремонт электрической плиты</option>
                    <option class="form-control" value="Ремонт льдогенератора">Ремонт льдогенератора</option>
                    <option class="form-control" value="Ремонт вафельницы">Ремонт вафельницы</option>
                    <option class="form-control" value="Ремонт кофеварки">Ремонт кофеварки</option>
                    <option class="form-control" value="Ремонт кофемолки">Ремонт кофемолки</option>
                    <option class="form-control" value="Ремонт парогенератор">Ремонт парогенератор</option>
                    <option class="form-control" value="Ремонт увлажнителя воздуха">Ремонт увлажнителя воздуха</option>
                    <option class="form-control" value="Ремонт инкубатора">Ремонт инкубатора</option>
                    <option class="form-control" value="Ремонт хлебопечки">Ремонт хлебопечки</option>
                    <option class="form-control" value="Ремонт пароварки">Ремонт пароварки</option>
                    <option class="form-control" value="Ремонт посудомоечной машины">Ремонт посудомоечной машины</option>
                </select>
            </div>
            <div class="mt-3">
                <button class="btn btn-primary" type="submit">Отправить</button>
            </div>
    </div>
</form>