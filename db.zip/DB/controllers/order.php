<?php
require ('db.php');
class order extends DB
{
    public function get(){
        return $this->DBAll("SELECT * FROM orders Left Outer Join customers ON customers_id = customers.id_customers
WHERE orders.customers_id = customers.id_customers;");
        return $this->DBAll("SELECT * FROM users Join customers ON id_users = customers.users_id
WHERE users.id_users = customers.users_id;");
    }
    public function deleteOrder($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from orders where id_orders='.$req->id_orders,
            'Заказ отменён');
    }

    public function createOrder($request){
        $req = json_decode($request);
        $start = $req->start;
        $names = $req->names;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO orders (start, names) values ('{$start}','{$names}')");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}