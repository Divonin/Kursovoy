<?php
require_once('../layout/header.php');
require ('../../controllers/Menu.php');
$db= new Menu();
?>
<body>
<?php
if(isset($_GET['message'])){
    echo $_GET['message'];
}
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2 border_width">
    <div>Услуги</div>
    <div>
        <a class="knopka" href="/views/admin/menu.php">Пользователи</a>
    </div>
    <form action="../../middleware/auth/logout.php" method="post">
        <button class="btn btn-primary" type="submit"
        onclick="document.location.replace('middleware/auth/logout.php');">Выход</button>
    </form>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>Название</th>
        <th>Сроки</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->getData();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['name'];?></td>
            <td><?php echo $row['description'];?></td>
            <td><?php echo $row['price'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
</div>
<script src="/public/js/bootstrap.bundle.min.js"></script>
</body>
</html>

