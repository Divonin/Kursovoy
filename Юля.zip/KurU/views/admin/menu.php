<?php
require ('../layout/header.php');
require ('../../controllers/Staff.php');
?>
<div>
    <a class="knopka" href="index.php">Главная</a>
</div>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div>Сотрудники</div>
    <div>
        <a class="knopka" href="create.php">Добавить сотрудника</a>
        <a class="knopka" href="update.php">Изменить данные сотрудника</a>
        <a class="knopka" href="delete.php">Удалить сотрудника</a>
        <a class="knopka" href="../menuha.php">Блюда</a>
        <a class="knopka" href="create_menu.php">Добавить блюдо</a>
        <a class="knopka" href="update_menu.php">Изменить блюдо</a>
        <a class="knopka" href="delete_menu.php">Удалить блюдо</a>
    </div>
</div>
<div class="container mx-auto">
    <table class="table table-hover table-dark">
        <tr>
            <th>id</th>
            <th>Фамилия</th>
            <th>Имя</th>
            <th>Отчество</th>
            <th>Опыт</th>
            <th>Зарплата</th>
        </tr>
        <?php
        $user = new Staff();
        $data = $user->get();
        foreach ($data as $key=>$row){
            ?>
            <tr>
                <td><?php echo $row ['id']?></td>
                <td><?php echo $row ['last_name']?></td>
                <td><?php echo $row ['name']?></td>
                <td><?php echo $row ['father_name']?></td>
                <td><?php echo $row ['experience']?></td>
                <td><?php echo $row ['wages']?></td>
            </tr>
        <?php }?>
    </table>