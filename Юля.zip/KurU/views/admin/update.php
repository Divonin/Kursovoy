<?php
require_once('../layout/header.php');
require_once('../../controllers/Staff.php');
$db = new Staff();
?>
<div>
    <a class="knopka" href="menu.php">Назад</a>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th>id</th>
        <th>Фамилия</th>
        <th>Имя</th>
        <th>Отчество</th>
        <th>Опыт</th>
        <th>ЗП</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->get();
    foreach ($data as $key => $row) {
        ?>
        <tr>
            <form class="mx-2" action="../../middleware/admin/update_staff.php" method="post">
                <td>
                    <?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row["id"]; ?>" class="form-control" hidden required>
                </td>
                <td>
                    <input id="last_name" name="last_name" type="text" value="<?php echo $row["last_name"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="name" name="name" type="text" value="<?php echo $row["name"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="father_name" name="father_name" type="text" value="<?php echo $row["father_name"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="experience" name="experience" type="text" value="<?php echo $row["experience"]; ?>" class="form-control" required>
                </td>
                <td>
                    <input id="wages" name="wages" type="text" value="<?php echo $row["wages"]; ?>" class="form-control" required>
                </td>
                <td>
                    <button type="submit" class="btn btn-primary">Изменить</button>
                </td>
            </form>
        </tr>
    <?php } ?>
    </tbody>
</table>

