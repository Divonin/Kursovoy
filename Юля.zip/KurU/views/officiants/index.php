<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
$db = new Orders();
?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/public/css/bootstrap.min.css">
</head>
<body>
<?php
if(isset($_GET['message'])){
    echo $_GET['message'];
}
?>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div>
        <a class="knopka" href="menu.php">Действия с заказами</a>
    </div>
    <form action="../../middleware/auth/logout.php" method="post">
        <button class="btn btn-primary" type="submit"  onclick="document.location.replace('../../middleware/auth/logout.php');">Выход</button>
    </form>
</div>
<table class="table table-hover table-dark">
    <thead>
    <tr>
        <th> </th>
        <th>Дата</th>
        <th>Название</th>
        <th>Стоимость</th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data = $db->get();
    foreach ($data as $key=>$row){
        ?>
        <tr>
            <td><?php echo ++$key;?></td>
            <td><?php echo $row['date'];?></td>
            <td><?php echo $row['name_dish'];?></td>
            <td><?php echo $row['price'];?></td>
        </tr>
    <?php }?>
    </tbody>
</table>