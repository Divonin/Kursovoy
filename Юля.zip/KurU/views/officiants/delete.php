<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Orders.php');
?>
<div>
    <a class="knopka" href="menu.php">Назад</a>
</div>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Orders();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Дата: </span> <span class="card-text"><?php echo $row['date'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Название блюда: </span> <span class="card-text"><?php echo $row['name_dish'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Цена: </span> <span class="card-text"><?php echo $row['price'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/officiants/delete_orders.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
