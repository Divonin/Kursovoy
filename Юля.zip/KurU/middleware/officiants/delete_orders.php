<?php
require_once ('../../controllers/Orders.php');
$db = new Orders();
$id = $_POST['id'];

$res = $db->deleteOrders(json_encode([
    'id'=>$id
]));

header('Location: ../../views/officiants/menu.php?message='. json_decode($res)->message);