<?php
require_once('../../controllers/Staff.php');
$db = new Staff();
$id = $_POST['id'];
$last_name = $_POST['last_name'];
$name = $_POST['name'];
$father_name = $_POST['father_name'];
$experience = $_POST['experience'];
$wages = $_POST['wages'];

$res = $db->updateOfficiant(json_encode([
    'id'=>$id,
    'last_name'=>$last_name,
    'name'=>$name,
    'father_name'=>$father_name,
    'experience'=>$experience,
    'wages'=>$wages,
]));

header('Location: ../../views/admin/menu.php?message='.json_decode($response)->message);
