<?php
require_once ('../../controllers/Menu.php');
$db = new Menu();
$id = $_POST['id'];

$response = $db->deleteMenu(json_encode([
    'id'=>$id
]));

header('Location: ../index2.php?message='. json_decode($response)->message);

