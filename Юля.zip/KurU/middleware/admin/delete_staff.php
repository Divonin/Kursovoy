<?php
require_once ('../../controllers/Staff.php');
$db = new Staff();
$id = $_POST['id'];

$res = $db->deleteOfficiant(json_encode([
    'id'=>$id
]));

header('Location: ../../views/admin/menu.php?message='.json_decode($response)->message);
