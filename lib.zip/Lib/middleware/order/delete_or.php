<?php
require_once ('../../controllers/Orders.php');
$db = new Orders();
$id = $_POST['id'];

$res = $db->deleteOrder(json_encode([
    'id'=>$id
]));

header('Location: ../../views/auth/index.php?message='. json_decode($res)->message);