<?php
require ('../layout/header.php');
require ('../../controllers/Books.php');
?>
<div>
    <a class="knopa" href="index.php">На главную</a>
</div>
<div class="container mx-auto">
    <a class="knopka" href="create_order.php">Заказать</a>
    <a class="knopka" href="delete_order.php">Удалить</a>
</div>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Books();
        $data = $user->get();
        foreach ($data as $key => $row) {
            ?>
            <div class="card m-2 shadow" style="background-color: #60ee9f">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Название: </span>
                        <span class="card-text"><?php echo $row['name']; ?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Количество: </span>
                        <span class="card-text"><?php echo $row['count']; ?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Статус: </span>
                        <span class="card-text"><?php echo $row['status']; ?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Дата издания: </span>
                        <span class="card-text"><?php echo $row['date']; ?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Цена: </span>
                        <span class="card-text"><?php echo $row['price']; ?></span>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
