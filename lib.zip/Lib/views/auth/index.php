ДЛЯ КЛИЕНТОВ
<?php
require ('../layout/header.php');
require ('../../controllers/Orders.php');
$db= new Orders();
?>
<div class="container mx-auto border d-flex justify-content-between">
    <a class="knopa" href="books.php">Книги</a>
    <form action="../../middleware/auth/logout.php" method="post">
        <button class="btn btn-light" type="submit"  onclick="document.location.replace('middleware/auth/logout.php');">Выход</button>
    </form>
</div>
<table class="table table-hover table-info">
    <thead>
    <tr>
        <th> </th>
        <th>Названия книг</th>
        <th>Дата</th>
        <th>Цена</th>
    </tr>
    </thead>
    <tbody>
<?php
$data = $db->Get();
foreach ($data as $key=>$row){
    ?>
    <tr>
        <td><?php echo ++$key;?></td>
        <td><?php echo $row['name_book'];?></td>
        <td><?php echo $row['date'];?></td>
        <td><?php echo $row['price'];?></td>
    </tr>
<?php }?>
</tbody>
</table>

