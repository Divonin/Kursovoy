<div>
    <a class="knopa" href="index.php">Главная</a>
</div>
<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Orders.php');
?>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Orders();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Название услуги: </span>
                        <span class="card-text"><?php echo $row['name_book'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Дата заказа: </span>
                        <span class="card-text"><?php echo $row['date'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Стоимость: </span>
                        <span class="card-text"><?php echo $row['price'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/order/delete_or.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Отменить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
