<div>
    <a class="knopa" href="index.php">Главная</a>
</div>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div>
        <a class="knopa" href="create_staff.php">Добавить сотрудника</a>
        <a class="knopa" href="update_staff.php">Изменить данные сотрудника</a>
        <a class="knopa" href="delete_staff.php">Удалить сотрудника</a>
    </div>
</div>