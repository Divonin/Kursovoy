<?php
require_once ('../layout/header.php');
require_once ('../../controllers/Books.php');
?>
<div>
    <a class="knopa" href="books.php">Главная</a>
</div>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Books();
        $data = $user->get();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Название: </span>
                        <span class="card-text"><?php echo $row['name'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Кол-во: </span>
                        <span class="card-text"><?php echo $row['count'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Статус: </span>
                        <span class="card-text"><?php echo $row['status'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Дата: </span>
                        <span class="card-text"><?php echo $row['date'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Цена: </span>
                        <span class="card-text"><?php echo $row['price'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/books/delete.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
