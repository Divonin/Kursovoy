<?php
require ('../layout/header.php');
require ('../../controllers/Staff.php');
$db=new Staff();
?>
<div>
    <a class="knopa" href="staff.php">На главную</a>
</div>
<table class="table table-info">
    <thead>
    <tr>
        <th> </th>
        <th>Логин</th>
        <th>Мэил</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data=$db->getD();
    foreach ($data as $key => $row){
        ?>
        <tr>
            <form action="../../middleware/staff/update.php" method="post">
                <td><?php echo ++$key; ?>
                    <input id="id" name="id" type="text" value="<?php echo $row['id']?>"  hidden required>
                </td>
                <td>
                    <input id="login" name="login" type="text" value="<?php echo $row['login']?>" class="form-control" required>
                </td>
                <td>
                    <input id="Email" name="Email" type="email" value="<?php echo $row['Email']?>" class="form-control" required>
                </td>
                <td>
                    <button class="btn btn-primary" type="submit">Изменить</button>
                </td>
            </form>
        </tr>
    <?php }?>
    </tbody>
</table>
