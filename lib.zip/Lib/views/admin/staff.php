<?php
require ('../layout/header.php');
require ('menu2.php');
require ('../../controllers/Staff.php');?>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Staff();
        $data = $user->getD();
        foreach ($data as $key => $row) {
            ?>
            <div class="card m-2 shadow" style="background-color: #60ee9f">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Логин: </span>
                        <span class="card-text"><?php echo $row['login']; ?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Мэил: </span>
                        <span class="card-text"><?php echo $row['Email']; ?></span>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>