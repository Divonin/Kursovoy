<?php
require ('../layout/header.php');
require ('../../controllers/Books.php');
$db=new Books();
?>
<div>
    <a class="knopa" href="books.php">На главную</a>
</div>
<table class="table table-info">
    <thead>
    <tr>
    <th> </th>
    <th>Название</th>
    <th>Кол-во</th>
    <th>Статус</th>
    <th>Дата издания</th>
    <th>Цена</th>
    <th> </th>
    </tr>
    </thead>
    <tbody>
    <?php
    $data=$db->get();
    foreach ($data as $key => $row){
    ?>
    <tr>
        <form action="../../middleware/books/update.php" method="post">
        <td><?php echo ++$key; ?>
            <input id="id" name="id" type="text" value="<?php echo $row['id']?>"  hidden required>
        </td>
        <td>
            <input id="name" name="name" type="text" value="<?php echo $row['name']?>" class="form-control" required>
        </td>
        <td>
            <input id="count" name="count" type="text" value="<?php echo $row['count']?>" class="form-control" required>
        </td>
        <td>
            <input id="status" name="status" type="text" value="<?php echo $row['status']?>" class="form-control" required>
        </td>
        <td>
            <input id="date" name="date" type="date" value="<?php echo $row['date']?>" class="form-control" required>
        </td>
        <td>
            <input id="price" name="price" type="text" value="<?php echo $row['price']?>" class="form-control" required>
        </td>
        <td>
            <button class="btn btn-primary" type="submit">Изменить</button>
        </td>
        </form>
    </tr>
    <?php }?>
    </tbody>
</table>

