<?php
require ('views/layout/header.php');
?>
<div class="container mb-3 d-flex justify-content-between align-items-center p-2">
    <div>
        <a class="knopa" href="/index.php">Главная</a>
    </div>
    <div>
        <a class="knopa" href="views/books.php">Книги</a>
    </div>
    <div>
        <a class="knopa" href="views/auth/auth.php" >Вход</a>
        <a class="knopa" href="views/auth/reg.php" >Регистрация</a>
    </div>
</div>
<div class="columns" >
    <div class="column main-column " style="background-color: #60ee9f">
        <table>
        <tr>
            <th> </th>
            <th>Фото</th>
        </tr>
        <tr>
            <td></td>
            <td><img src="https://heaclub.ru/tim/46bb146a6001af51b0b581652f83a10b/dorogaya-zapisnaya-knizhka-v-podarok.jpg" alt=""></td>
        </tr>
        </table>
    </div>
    <div class="column" style="background-color: #60eea7">
        <table class="table-warning">
            <tr>
                <th>Новости</th>
            </tr>
            <tr>
                <td style="color: white">Тут нет их, ушли на обед</td>
            </tr>
        </table>
    </div>
</div>