<?php

require ('db.php');

class Staff extends db
{
public function getD (){
    return $this->DBAll('Select * from staff');
}
    public function get (){
        return $this->DBAll('Select * from users');
    }
    public function deleteStaff($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from staff where id='.$req->id,
            'Пользователь удален');
        return $this->transaction(
            'DELETE from users where id='.$req->id,
            'Пользователь удален');
    }
    public function createStaff($request){
        $req = json_decode($request);
        $login = $req->login;
        $Email = $req->Email;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO staff (login,Email) values ('{$login}','{$Email}')");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO users (login,Email) values ('{$login}','{$Email}')");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateU($request){
        $req = json_decode($request);
        $id_users = $req->id_users;
        $password = $req->password;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE users SET password='{$password}' WHERE id_users={$id_users} ");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function updateStaff($request){
        $req = json_decode($request);
        $id = $req->id;
        $login = $req->login;
        $Email = $req->Email;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE staff SET login='{$login}', Email='{$Email}' WHERE id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Пользователь обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
}