<?php

require ('db.php');

class Orders extends db
{
public function Get(){
    return $this->DBAll("Select * from orders");
}
    public function deleteOrder($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from orders where id='.$req->id,
            'Заказ удален');
    }
 public function createOrder($request){
         $req = json_decode($request);
         $name_book = $req->name_book;
         $date = $req->date;
         $price=$req->price;
         $connect = $this->connect();
         try{
             $connect->beginTransaction();
             $connect->exec("INSERT INTO orders (name_book, date, price) value ('{$name_book}','{$date}','{$price}')");
             $connect->commit();
             return json_encode([
                 'message'=>'Заказ добавлен'
             ]);
         }catch (PDOException $e){
             $connect->rollBack();
             return json_encode([
                 'message'=>$e->getMessage()
             ]);
         }
     }
}