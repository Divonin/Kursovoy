<?php
require ('db.php');
class roles extends db
{
    public function login($request)
    {
        $req = json_decode($request);
        $login = $req->login;
        $Email = $req->Email;
        $password = $req->password;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from users where login=:login and Email=:Email and password=:pass');
        $sql->execute([

            'login' => $login,
            'Email' => $Email,
            'pass' => $password,
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'login' => $data->login,
                'Email' => $data->Email,
                'role' => $data->role
            ];
        }
    }

    public function registration($request)
    {
        $req = json_decode($request);
        $login = $req->login;
        $Email = $req->Email;
        $password = $req->password;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from users where login=:login and Email=:Email and password=:pass');
        $sql->execute(array(
            'login' => $login,
            'Email' => $Email,
            'pass' => $password,
        ));
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            return json_encode([
                'message' => "Такой пользователь существует"
            ]);
        }
        $req = json_decode($request);
        $login = $req->login;
        $Email = $req->Email;
        $connect = $this->connect();
        $sql = $connect->prepare('SELECT * from customers where login=:login and Email=:Email');
        $sql->execute(array(
            'login' => $login,
            'Email' => $Email,
        ));
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            return json_encode([
                'message' => "Такой пользователь существует"
            ]);
        }
        $sql = $connect->prepare("INSERT INTO users(login, Email,password,role) values (:login,:Email,:pass,:role)");
        $sql->execute([
            'login' => $login,
            'Email' => $Email,
            "pass" => $password,
            "role" => 3
        ]);
        $sql = $connect->prepare("INSERT INTO customers (login, Email) values (:login,:Email)");
        $sql->execute([
            'login' => $login,
            'Email' => $Email,
        ]);
        $sql = $connect->prepare('SELECT * from users where login=:login and Email=:Email and password=:pass');
        $sql->execute([
            'login' => $login,
            'Email' => $Email,
            'password' => $password,
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'login' => $data->login,
                'Email' => $data->Email,
                'role' => $data->role
            ];
            return json_encode([
                'message' => 'Пользователь добавлен'
            ]);
        }
        $sql = $connect->prepare('SELECT * from customers where login=:login and Email=:Email');
        $sql->execute([
            'login' => $data->login,
            'Email' => $data->Email
        ]);
        $data = $sql->fetch(PDO::FETCH_OBJ);
        if ($data) {
            session_start();
            $_SESSION['user'] = (object)[
                'login' => $data->login,
                'Email' => $data->Email
            ];
            return json_encode([
                'message' => 'Пользователь добавлен'
            ]);
        }
    }
}