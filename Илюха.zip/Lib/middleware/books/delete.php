<?php
require_once ('../../controllers/Books.php');
$db = new Books();
$id = $_POST['id'];

$res = $db->delete(json_encode([
    'id'=>$id
]));

header('Location: ../../views/admin/books.php?message='. json_decode($res)->message);