<?php
require ('../../controllers/Books.php');
$db = new Books();
$id = $_POST['id'];
$name = $_POST['name'];
$count = $_POST['count'];
$status = $_POST['status'];
$date = $_POST['date'];
$price = $_POST['price'];
$res = $db ->update(json_encode([
    'id'=>$id,
    'name'=>$name,
    'count'=>$count,
    'status'=>$status,
    'date'=>$date,
    'price'=>$price,
]));
header('Location: ../../views/admin/books.php?message='. json_decode($res)->message);