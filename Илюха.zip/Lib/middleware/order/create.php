<?php
require('../../controllers/Orders.php');
$db = new Orders();
$name_book = $_POST['name_book'];
$date = $_POST['date'];
$price = $_POST['price'];

$response = $db->createOrder(json_encode([
    'name_book'=>$name_book,
    'date'=>$date,
    'price'=>$price,
]));

header('Location: ../../views/auth/index.php?message='.json_decode($response)->message);
