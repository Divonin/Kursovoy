<?php
require ('../../controllers/Staff.php');
$db = new Staff();
$id = $_POST['id'];
$login = $_POST['login'];
$Email = $_POST['Email'];
$res = $db ->updateStaff(json_encode([
    'id'=>$id,
    'login'=>$login,
    'Email'=>$Email
]));
header('Location: ../../views/admin/staff.php?message='. json_decode($res)->message);