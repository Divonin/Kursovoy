<?php
require_once ('../../controllers/Staff.php');
$db = new Staff();
$id = $_POST['id'];

$res = $db->deleteStaff(json_encode([
    'id'=>$id
]));

header('Location: ../../views/admin/staff.php?message='. json_decode($res)->message);