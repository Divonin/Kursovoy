<?php
require ('../../controllers/Staff.php');
$db = new Staff();
$login = $_POST['login'];
$Email = $_POST['Email'];
$res = $db ->createStaff(json_encode([
    'login'=>$login,
    'Email'=>$Email
]));
header('Location: ../../views/admin/staff.php?message='. json_decode($res)->message);