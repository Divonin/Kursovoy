<?php
require('../../controllers/roles.php');
$db = new roles();
$login = $_POST['login'];
$Email = $_POST['Email'];
$password = $_POST['password'];

$db->login(json_encode([
    'login' => $login,
    'Email' => $Email,
    'password'=>$password,
]));
session_start();
if($_SESSION['user']->role===3) {
    header('Location: ../../views/auth/index.php');
}
if($_SESSION['user']->role===2) {
    header('Location: ../../views/staff/index.php');
}
if($_SESSION['user']->role===1) {
    header('Location: ../../views/admin/index.php');
}