<?php
require('../../controllers/roles.php');
$db = new roles();
$login = $_POST['login'];
$Email = $_POST['Email'];
$password = $_POST['password'];

$response = $db->registration(json_encode([
    'login' => $login,
    'Email' => $Email,
    'password'=>$password,
]));

header('Location: ../../views/auth/auth.php');