<div>
    <a class="knopa" href="index.php">В меню</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/Orders.php');
?>
<div class="container mt-5">
    <form action="../../middleware/order/create.php"
          method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3>Создание</h3>
        <?php
        $a = date("Y-m-d");
        ?>
        <div class="col-3">
            <label for="date">Старт</label>
            <input id="date" name="date" type="date" value="<?php echo $a?>" class="form-control"  required>
        </div>
        <div class="col-3">
            <label for="name_book">Название услуги</label>
            <input id="name_book" name="name_book" type="text" class="form-control" placeholder="Название книги" required>
        </div>
        <div class="col-3">
            <label for="price">Стоимость</label>
            <input id="price" name="price" type="text" class="form-control" placeholder="Стоимость" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div