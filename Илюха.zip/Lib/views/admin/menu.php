<div>
    <a class="knopa" href="index.php">Главная</a>
</div>
<div class="container d-flex justify-content-between align-items-center p-2 mb-2">
    <div>
        <a class="knopa" href="create.php">Добавить книгу</a>
        <a class="knopa" href="update.php">Изменить данные книги</a>
        <a class="knopa" href="delete.php">Удалить книгу</a>
    </div>
</div>