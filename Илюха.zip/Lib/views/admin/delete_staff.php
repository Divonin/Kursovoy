<?php
require_once ('../layout/header.php');
require_once ('menu2.php');
require_once ('../../controllers/Staff.php');
?>
<div class="container mx-auto">
    <div style="display: grid; grid-template-columns: repeat(3,1fr)">
        <?php
        $user = new Staff();
        $data = $user->getD();
        foreach ($data as $key =>$row){
            ?>
            <div class="card m-2 shadow">
                <div class="card-body">
                    <div>
                        <span class="card-subtitle text-muted">Логин: </span>
                        <span class="card-text"><?php echo $row['login'];?></span>
                    </div>
                    <div>
                        <span class="card-subtitle text-muted">Мэил: </span>
                        <span class="card-text"><?php echo $row['Email'];?></span>
                    </div>
                    <div class="my-2">
                        <form action="../../middleware/staff/delete.php" method="post">
                            <input name="id" value="<?php echo $row['id'];?>" type="text" hidden>
                            <button class="btn btn-danger" type="submit">Удалить</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php }?>
    </div>
</div>
