<div>
    <a class="knopa" href="staff.php">В меню</a>
</div>
<?php
require ('../layout/header.php');
require_once('../../controllers/Staff.php');
?>
<div class="container mt-5">
    <form action="../../middleware/staff/create.php" method="post"
          class="d-flex flex-column justify-content-center align-items-center">
        <h3 style="background-color: white">Создание</h3>
        <div class="col-3">
            <label style="background-color: white" for="login">Логин</label>
            <input id="login" name="login" type="text" class="form-control" placeholder="Логин" required>
        </div>
        <div class="col-3">
            <label style="background-color: white" for="Email">Email</label>
            <input id="Email" name="Email" type="text" class="form-control" placeholder="Мэил" required>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" type="submit">Отправить</button>
        </div>
    </form>
</div