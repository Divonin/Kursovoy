<?php
require ('db.php');

class Books extends db
{
 public function get(){
     return $this->DBAll('SELECT * from books');
}
    public function create($request){
        $req = json_decode($request);
        $name = $req->name;
        $count = $req->count;
        $status = $req->status;
        $date = $req->date;
        $price = $req->price;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("INSERT INTO books(name,count,status,date,price) values ('{$name}','{$count}','{$status}','{$date}','{$price}')");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ добавлен'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function update($request){
        $req = json_decode($request);
        $id = $req->id;
        $name = $req->name;
        $count = $req->count;
        $status = $req->status;
        $date = $req->date;
        $price = $req->price;
        $connect = $this->connect();
        try{
            $connect->beginTransaction();
            $connect->exec("UPDATE books SET name='{$name}', count ='{$count}', status='{$status}', date='{$date}',
                  price='{$price}' WHERE id={$id} ");
            $connect->commit();
            return json_encode([
                'message'=>'Заказ обновлён'
            ]);
        }catch (PDOException $e){
            $connect->rollBack();
            return json_encode([
                'message'=>$e->getMessage()
            ]);
        }
    }
    public function delete($request){
        $req=json_decode($request);
        return $this->transaction(
            'DELETE from books where id='.$req->id,
            'Заказ удален');
    }
}